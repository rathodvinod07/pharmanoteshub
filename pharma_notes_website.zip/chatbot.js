
const apiKey = "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";

document.getElementById("chat-toggle").onclick = () => {
  const chatBox = document.getElementById("chat-box");
  chatBox.style.display = chatBox.style.display === "none" ? "block" : "none";
};

async function sendMessage() {
  const input = document.getElementById("chat-input");
  const message = input.value.trim();
  if (!message) return;

  appendMessage("You", message);
  input.value = "";

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: message }]
    })
  });

  const data = await response.json();
  const reply = data.choices[0].message.content.trim();
  appendMessage("AI", reply);
}

function appendMessage(sender, text) {
  const chat = document.getElementById("chat-messages");
  const msg = document.createElement("div");
  msg.innerHTML = `<strong>${sender}:</strong> ${text}`;
  chat.appendChild(msg);
  chat.scrollTop = chat.scrollHeight;
}
