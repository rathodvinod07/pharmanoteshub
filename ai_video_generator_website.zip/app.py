
from flask import Flask, request, send_file, render_template_string
from gtts import gTTS
from moviepy.editor import TextClip, AudioFileClip
import os
import uuid

app = Flask(__name__)

HTML_FORM = """{{ html_code }}"""

@app.route('/')
def home():
    return render_template_string(HTML_FORM, html_code=open('generate-video.html').read())

@app.route('/generate', methods=['POST'])
def generate():
    prompt = request.form['prompt']
    audio_file = f"{uuid.uuid4()}.mp3"
    video_file = f"{uuid.uuid4()}.mp4"

    # Generate speech
    tts = gTTS(prompt)
    tts.save(audio_file)

    # Create video
    text_clip = TextClip(prompt, fontsize=48, color='white', size=(1280, 720), bg_color='black', method='caption')
    text_clip = text_clip.set_duration(10).set_position('center')
    audio = AudioFileClip(audio_file)
    text_clip = text_clip.set_audio(audio)
    text_clip.write_videofile(video_file, fps=24)

    # Cleanup
    os.remove(audio_file)

    return send_file(video_file, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
